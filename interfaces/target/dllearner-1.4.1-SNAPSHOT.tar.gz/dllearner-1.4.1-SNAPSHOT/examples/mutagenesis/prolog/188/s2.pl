active(d10).
active(d61).
active(d86).
active(d94).
active(d105).
active(d128).
active(d173).
active(d183).
active(d29).
:- active(d42).
:- active(d147).
:- active(d186).
:- active(d3).
:- active(d5).
:- active(d39).
:- active(d78).
:- active(d142).
:- active(d182).
:- active(d185).
