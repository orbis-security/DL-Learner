active(d11).
active(d27).
active(d53).
active(d56).
active(d68).
active(d146).
active(d33).
active(d74).
:- active(d188).
:- active(d7).
:- active(d9).
:- active(d14).
:- active(d36).
:- active(d40).
:- active(d123).
:- active(d135).
:- active(d150).
:- active(d155).
:- active(d175).
