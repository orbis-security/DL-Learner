active(d1).
active(d12).
active(d20).
active(d31).
active(d83).
active(d115).
active(d164).
active(d165).
active(d166).
active(d184).
active(d16).
active(d99).
active(d102).
active(d145).
active(d161).
active(d170).
:- active(d114).
:- active(d19).
:- active(d133).
