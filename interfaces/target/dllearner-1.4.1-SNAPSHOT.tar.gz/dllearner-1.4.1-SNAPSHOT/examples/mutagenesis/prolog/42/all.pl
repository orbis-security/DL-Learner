active(d190).
active(d191).
active(d194).
active(d197).
active(e1).
active(e2).
active(e27).
active(f1).
active(f2).
active(f3).
active(f4).
active(f5).
active(f6).
:- active(d189).
:- active(d192).
:- active(d193).
:- active(d195).
:- active(d196).
:- active(e10).
:- active(e11).
:- active(e12).
:- active(e13).
:- active(e14).
:- active(e15).
:- active(e16).
:- active(e17).
:- active(e18).
:- active(e19).
:- active(e20).
:- active(e21).
:- active(e22).
:- active(e23).
:- active(e24).
:- active(e25).
:- active(e26).
:- active(e3).
:- active(e4).
:- active(e5).
:- active(e6).
:- active(e7).
:- active(e8).
:- active(e9).
