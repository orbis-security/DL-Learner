The data for carcinogenesis prediction was contributed to the Machine
Learning community by the U.S. National Toxicology Program (NTP) [1].
They were made available in Progol/Prolog format [2]. DL-Learner 
contains a Prolog parser, which was used to read in the data. Using a
set of mapping rules, they were converted into an OWL ontology, which
is made available here.

http://ntp-server.niehs.nih.gov/
http://web2.comlab.ox.ac.uk/oucl/research/areas/machlearn/cancer.html
