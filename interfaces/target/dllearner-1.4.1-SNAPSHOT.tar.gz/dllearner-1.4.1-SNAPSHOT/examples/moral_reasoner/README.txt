Moral Reasoner Examples
=======================

Taken from http://mlearn.ics.uci.edu/databases/moral-reasoner/.

Explanations for the files in this directory:

OWL-files:
  - "43instances" means that the number of instances has been reduced to 43
    from the original example
  - "complex" means that a definition has been left out to make the learned
    concept more complex
  - complete

Conf-files:
  - "43examples" means that these learning examples do not use all examples but
     just 43
  - "owl" means that these examples read the corresponding OWL files (instead
     of using internal Syntax in conf files)
