The examples contained in this directory were taken from the YinYang learning 
system developed by Luigi Iannone and converted for use with DL-Learner.
