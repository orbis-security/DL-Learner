active(d6).
active(d15).
active(d69).
active(d71).
active(d87).
active(d95).
active(d104).
active(d109).
active(d177).
active(d187).
active(d44).
active(d93).
active(d97).
active(d106).
:- active(d132).
:- active(d141).
:- active(d73).
:- active(d76).
:- active(d113).
