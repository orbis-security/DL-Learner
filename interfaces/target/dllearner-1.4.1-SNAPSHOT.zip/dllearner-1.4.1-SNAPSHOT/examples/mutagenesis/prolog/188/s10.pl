active(d48).
active(d60).
active(d112).
active(d148).
active(d157).
active(d35).
active(d81).
active(d91).
active(d103).
active(d118).
active(d162).
:- active(d89).
:- active(d138).
:- active(d144).
:- active(d55).
:- active(d110).
:- active(d156).
