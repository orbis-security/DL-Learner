active(d18).
active(d26).
active(d28).
active(d51).
active(d63).
active(d67).
active(d107).
active(d127).
active(d137).
active(d151).
active(d174).
active(d178).
active(d85).
active(d92).
:- active(d38).
:- active(d84).
:- active(d100).
:- active(d116).
:- active(d160).
