active(d4).
active(d41).
active(d49).
active(d50).
active(d59).
active(d96).
active(d117).
active(d136).
active(d153).
active(d23).
active(d32).
active(d158).
active(d167).
active(d176).
:- active(d98).
:- active(d88).
:- active(d124).
:- active(d139).
:- active(d168).
