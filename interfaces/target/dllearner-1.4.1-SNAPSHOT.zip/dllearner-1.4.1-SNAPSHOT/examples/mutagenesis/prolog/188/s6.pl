active(d25).
active(d45).
active(d54).
active(d58).
active(d75).
active(d101).
active(d140).
active(d149).
active(d159).
active(d171).
active(d8).
active(d47).
active(d121).
active(d134).
:- active(d70).
:- active(d77).
:- active(d111).
:- active(d62).
:- active(d179).
