active(d46).
active(d52).
active(d57).
active(d80).
active(d82).
active(d125).
active(d152).
active(d169).
active(d21).
active(d22).
active(d108).
active(d180).
:- active(d119).
:- active(d34).
:- active(d65).
:- active(d66).
:- active(d143).
:- active(d154).
:- active(d181).
