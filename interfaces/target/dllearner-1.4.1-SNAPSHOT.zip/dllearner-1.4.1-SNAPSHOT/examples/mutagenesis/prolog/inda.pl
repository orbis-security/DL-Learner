inda(d1,0.0).
inda(d2,0.0).
inda(d3,0.0).
inda(d4,0.0).
inda(d5,0.0).
inda(d6,0.0).
inda(d7,0.0).
inda(d8,0.0).
inda(d9,0.0).

inda(d10,0.0).
inda(d11,0.0).
inda(d12,0.0).
inda(d13,0.0).
inda(d14,0.0).
inda(d15,0.0).
inda(d16,0.0).
inda(d17,0.0).
inda(d18,0.0).
inda(d19,0.0).

inda(d20,0.0).
inda(d21,0.0).
inda(d22,0.0).
inda(d23,1.0).
inda(d24,0.0).
inda(d25,0.0).
inda(d26,0.0).
inda(d27,0.0).
inda(d28,0.0).
inda(d29,0.0).

inda(d30,1.0).
inda(d31,0.0).
inda(d32,0.0).
inda(d33,0.0).
inda(d34,0.0).
inda(d35,0.0).
inda(d36,0.0).
inda(d37,0.0).
inda(d38,0.0).
inda(d39,0.0).

inda(d40,0.0).
inda(d41,0.0).
inda(d42,0.0).
inda(d43,0.0).
inda(d44,0.0).
inda(d45,0.0).
inda(d46,0.0).
inda(d47,0.0).
inda(d48,0.0).
inda(d49,0.0).

inda(d50,0.0).
inda(d51,0.0).
inda(d52,0.0).
inda(d53,0.0).
inda(d54,0.0).
inda(d55,0.0).
inda(d56,0.0).
inda(d57,0.0).
inda(d58,0.0).
inda(d59,1.0).

inda(d60,0.0).
inda(d61,0.0).
inda(d62,0.0).
inda(d63,0.0).
inda(d64,0.0).
inda(d65,0.0).
inda(d66,0.0).
inda(d67,0.0).
inda(d68,0.0).
inda(d69,0.0).

inda(d70,0.0).
inda(d71,0.0).
inda(d72,0.0).
inda(d73,0.0).
inda(d74,0.0).
inda(d75,0.0).
inda(d76,0.0).
inda(d77,0.0).
inda(d78,0.0).
inda(d79,0.0).

inda(d80,0.0).
inda(d81,0.0).
inda(d82,0.0).
inda(d83,0.0).
inda(d84,0.0).
inda(d85,1.0).
inda(d86,1.0).
inda(d87,0.0).
inda(d88,0.0).
inda(d89,0.0).

inda(d90,0.0).
inda(d91,0.0).
inda(d92,0.0).
inda(d93,0.0).
inda(d94,0.0).
inda(d95,0.0).
inda(d96,0.0).
inda(d97,0.0).
inda(d98,0.0).
inda(d99,0.0).

inda(d100,0.0).
inda(d101,0.0).
inda(d102,0.0).
inda(d103,0.0).
inda(d104,0.0).
inda(d105,0.0).
inda(d106,0.0).
inda(d107,0.0).
inda(d108,0.0).
inda(d109,0.0).

inda(d110,0.0).
inda(d111,0.0).
inda(d112,0.0).
inda(d113,0.0).
inda(d114,0.0).
inda(d115,0.0).
inda(d116,0.0).
inda(d117,0.0).
inda(d118,0.0).
inda(d119,0.0).

inda(d120,0.0).
inda(d121,0.0).
inda(d122,0.0).
inda(d123,0.0).
inda(d124,0.0).
inda(d125,0.0).
inda(d126,0.0).
inda(d127,0.0).
inda(d128,0.0).
inda(d129,0.0).

inda(d130,0.0).
inda(d131,0.0).
inda(d132,0.0).
inda(d133,0.0).
inda(d134,0.0).
inda(d135,0.0).
inda(d136,0.0).
inda(d137,0.0).
inda(d138,0.0).
inda(d139,0.0).

inda(d140,0.0).
inda(d141,0.0).
inda(d142,0.0).
inda(d143,0.0).
inda(d144,0.0).
inda(d145,0.0).
inda(d146,0.0).
inda(d147,0.0).
inda(d148,0.0).
inda(d149,0.0).

inda(d150,0.0).
inda(d151,0.0).
inda(d152,0.0).
inda(d153,0.0).
inda(d154,0.0).
inda(d155,0.0).
inda(d156,0.0).
inda(d157,0.0).
inda(d158,0.0).
inda(d159,0.0).

inda(d160,0.0).
inda(d161,0.0).
inda(d162,0.0).
inda(d163,0.0).
inda(d164,0.0).
inda(d165,0.0).
inda(d166,0.0).
inda(d167,0.0).
inda(d168,0.0).
inda(d169,0.0).

inda(d170,0.0).
inda(d171,0.0).
inda(d172,0.0).
inda(d173,0.0).
inda(d174,0.0).
inda(d175,0.0).
inda(d176,0.0).
inda(d177,0.0).
inda(d178,0.0).
inda(d179,0.0).

inda(d180,0.0).
inda(d181,0.0).
inda(d182,0.0).
inda(d183,0.0).
inda(d184,0.0).
inda(d185,0.0).
inda(d186,0.0).
inda(d187,0.0).
inda(d188,0.0).








inda(d189,0.0).
inda(d190,0.0).
inda(d191,0.0).
inda(d192,0.0).
inda(d193,0.0).
inda(d194,0.0).
inda(d195,0.0).
inda(d196,0.0).
inda(d197,0.0).

inda(e1,0.0).
inda(e2,0.0).
inda(e3,0.0).
inda(e4,0.0).
inda(e5,0.0).
inda(e6,0.0).
inda(e7,0.0).
inda(e8,0.0).
inda(e9,0.0).
inda(e10,0.0).
inda(e11,0.0).
inda(e12,0.0).
inda(e13,0.0).
inda(e14,0.0).
inda(e15,0.0).
inda(e16,0.0).
inda(e17,0.0).
inda(e18,0.0).
inda(e19,0.0).
inda(e20,0.0).
inda(e21,0.0).
inda(e22,0.0).
inda(e23,0.0).
inda(e24,0.0).
inda(e25,0.0).
inda(e26,0.0).
inda(e27,0.0).
inda(f1,0.0).
inda(f2,0.0).
inda(f3,0.0).
inda(f4,0.0).
inda(f5,0.0).
inda(f6,0.0).
