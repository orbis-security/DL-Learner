This directory contains additional files, which are needed in order to test the 
DL-Learner examples with YinYang. Use run.bat (Windows) or run (other systems)
to run the examples. You have to adapt the path to YinYang in these files first.
